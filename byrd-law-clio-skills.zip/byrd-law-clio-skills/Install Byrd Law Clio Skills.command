#!/bin/bash
#
# Byrd Law Group — Clio Skills installer for Claude Cowork
# Double-click this file to install (or update) the firm's Clio skills.
# It copies the five skills into ~/.claude/skills/ where Cowork/Claude reads them.
#
set -e
cd "$(dirname "$0")"

DEST="$HOME/.claude/skills"
SRC="./skills"

echo "======================================================"
echo "  Byrd Law Group — Clio Skills for Claude Cowork"
echo "======================================================"
echo ""

if [ ! -d "$SRC" ]; then
  echo "ERROR: can't find the 'skills' folder next to this installer."
  echo "Make sure you unzipped the whole folder before running this."
  echo ""
  read -r -p "Press Return to close..." _
  exit 1
fi

mkdir -p "$DEST"

echo "Installing to: $DEST"
echo ""
for skill in "$SRC"/*/; do
  name="$(basename "$skill")"
  rm -rf "$DEST/$name"
  cp -R "$skill" "$DEST/$name"
  echo "  installed: $name"
done

echo ""
echo "Done. Installed these skills:"
ls -1 "$DEST" | sed 's/^/  - /'
echo ""
echo "NEXT STEPS:"
echo "  1. Quit and reopen Claude Cowork so it picks up the new skills."
echo "  2. Make sure your Clio access key (MATON_API_KEY) is set up —"
echo "     ask the office admin if you're not sure."
echo ""
echo "  Try it by typing in Cowork:"
echo "     \"Open a new MVA matter for a test client\""
echo ""
read -r -p "Press Return to close this window..." _
